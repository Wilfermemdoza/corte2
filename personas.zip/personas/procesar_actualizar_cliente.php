<?php

require "config/conexi.php";


$id = $_POST["id"];

$nombre = $_POST["nombre"];

$celular = $_POST["celular"];

$sql= "UPDATE clientes

SET

nombre='".$nombre."',

celular= '".$celular."'

WHERE

id=".$id.""; 

if($dbh->query($sql))



{


echo "persona actualizada correctamente";


}else
{
    
echo "error actualizacion persona";

}

?>