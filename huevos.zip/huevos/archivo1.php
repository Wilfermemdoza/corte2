<?php
require 'config/conexis.php';
$cantidad= $_POST["txt_cantidad"];
$tipo = $_POST["tipo"];
if($cantidad <=0 )
{
    echo "ha digitado valor incorrecto";
    exit;
}

if($tipo==1)
{
    $valor=2000;
    $total = $valor * $cantidad;
    }

    if($tipo==2)
{
    $valor=3000;
    $total = $valor * $cantidad;
    }

    if($tipo==3)
{
    $valor=4000;
    $total = $valor * $cantidad;
    }

$sql = "INSERT INTO registro(valor, cantidad, tipo) values (".$valor.",".$cantidad.",".$tipo.")";
if ($dbh->query($sql))

{
    echo "venta registrada".$total;
}else
{
    echo "error en la venta";
}

?>