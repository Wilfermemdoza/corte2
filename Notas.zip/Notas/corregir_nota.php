<?php
require "config/conexi.php";
$id = $_POST['id'];
$n1 = $_POST["n1"];
$n2 = $_POST["n2"];
$n3 = $_POST["n3"];

$final = ($n1 * 0.30) + ($n2 * 0.30) + ($n3 * 0.40); 

$sql= "UPDATE
    cortes
SET
    
    n1 = '".$n1."',
    n2 = '".$n2."',
    n3 = '".$n3."',
    final = '".$final."'
WHERE

id=".$id."";
if($dbh->query($sql))
{
echo "Nota Actualizada Correctamente";
}

else
{
    
echo "error actualizacion nota";

}

?>


