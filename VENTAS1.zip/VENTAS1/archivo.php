<?php
require 'config/conexi.php';
$cantidad = $_POST["txt_cantidad"];
$total = 1500 * $cantidad;

$sql = "INSERT INTO ventas(valor) values (".$total.")";
if ($dbh->query($sql))

{
    echo "venta registrada".$total;
}else
{
    echo "error en la venta";
}

?>